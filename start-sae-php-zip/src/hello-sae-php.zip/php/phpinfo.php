<?php
phpinfo();
